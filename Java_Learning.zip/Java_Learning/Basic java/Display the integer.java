/* Write a c program to accept the integer value and display the integer

Input Format

Accept an integer

Constraints

Nill

Output Format

Display the integer

Sample Input 0

20
Sample Output 0

20 */

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println(a);
    }
}