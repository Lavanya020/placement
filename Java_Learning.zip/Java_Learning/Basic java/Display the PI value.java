/*  Write a C program to display the value of PI accurate to 12 decimal places.

Input Format

Nill

Constraints

Nill

Output Format

Display the PI value

Sample Output 0

3.142857142857 */

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {

    public static void main(String[] args) {
        double pi = 3.142857142857;
        System.out.println(pi);
    }
}
