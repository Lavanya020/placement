/* Write a C program to find the LCM of the given two numbers.

Input Format

Integer Integer

Constraints

Nill

Output Format

Integer

Sample Input 0

8 5
Sample Output 0

40
*/

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int i=2;
        
        while(true)
        {
            if(i%a==0 && i%b==0){
                break;
            }
            i++;
        }
        
        System.out.println(i);
        
       
        
    }
}